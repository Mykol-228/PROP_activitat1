package edu.upc.epsevg.prop.lab3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author bernat
 */
public class Book {


    /**
     * Main program
     * @param args 
     */
    public static void main(String[] args) {

        Book b = new Book("Dracula.txt");
        b.readAllLinesFromTheBook();
        b.showFrequencyReport();
        
        Book r = new Book("RomeoAndJuliet.txt");
        r.readAllLinesFromTheBook();
        r.showFrequencyReport();
        
        r.compareWith(b);
    }

    /** Path of the book */
    String path;
    
    /**
     * Constructor
     * @param path  It is the book's file path
     */
    public Book(String path){
        this.path = path;
    }
    
    /**
     * This method compares this book with another. It 
     * outputs in the console the list of the ten 
     * most frequent common words, ordered descending 
     * by the sum of frequencies.
     * 
     * @param other book to be compared with
     */
    public void compareWith(Book other){
        System.out.println("     Top ten Most frequent common words");
        System.out.println("===============================================");
        // @TODO
    }
    
    /**
     * Update the frequency counter with the words appearing in the line .
     * @param line contains the words that should be accounted.
     */
    private void registerWordsInALine(String line) {
         System.out.println(line);
        //TODO
    }
    
    /**
     * Shows in stdout a list of words using the format:
     *    {word} - {frequency}
     * 
     * Words in the list should appear sorted by two criteria (both of them!):
     *  1.- descending frequency.
     *  2.- ascending alphabetical order
     */
    public void showFrequencyReport(){

        System.out.println("     Frequency report");
        System.out.println("============================");
        // @TODO
       
    }

    /**
     * read all the lines from the book and process each of them
     */
    public void readAllLinesFromTheBook() {
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(
                    this.path));
            String line = "";
            while ( (line=reader.readLine())!=null) {               
                registerWordsInALine(line);                
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
